/* 
 * Call auth APIs that we wrote in routes- api.js:  
 * call the  tokens, the route api.get and put them in authService.js
 * angular will call all the json values from server and render it to html
 * service will Fetch all the data and we pass it to the controller which will do logic
 * and it will pass it to a route and it route will render the view 
 * normal mvc pattern
 * 
 * most useful method is factory. it is organized
 * we get $http from http Request and pass in AuthToken
 * AuthToken will be a factory later on
 * create AuthFactory using a var  ; all of the API routes called using http will be put in AuthFactory var
 * authfactory.login will get api from  api.post ./login and it will login user and save it to frontend
* the prefix in nodeJS is the API  /login  the url is /api/login
* this is how to fetch data from server
* return a closure: username password
* success is a promise function
* like a callback function(res,req)
* this (data) is the Promise Object and the success will pass it Auth and put it into data.token
* and we are going to fetch the token and put it into 
* 
* AuthToken will be a factory created later
* 
* check if user is logged in or not; every http request check is user is logged in
* have a function to see if you have a token or not; much like middleware but for frontend
* 
* to get the user id and name and info about user we authFactory.getUser
* 
* you will return a route or url or api (all the same)  api.get and put it here /api/me
* 
* create AuthTokenFactory
*/

angular.module('authService',[])

        .factory('Auth', function($http, $q, AuthToken){
            
            var authFactory = {};
    
            authFactory.login = function(username, password) {
                return $http.post('/api/login',(
                    username: username,
                    password: password
        )

        .success(function(data){
            AuthToken.setToken(data.token);
            return data;
        })
 })
        
  
authFactory.logout = function(){
            AuthToken.setToken();
        }
         
authFactory.isLoggedIn = function(){
    if(AuthToken.getToken())
        return true;
        else
        return false;
    }
    
authFactory.getUser = function(){
        if(AuthToken.getToken())
            return $http.get('/api/me');
            else
            return $q.reject({message: "user has no token"});
    }
    return authFactory;
    
    });
    
    .factory('AuthToken', function(window){
        
        var authTokenFactory = {};

        authTokenFactory.getToken = function(){
                return $window.localStorage.getItem('token');
        }
        authTokenFactory.setToken = function(token){
                if (token)
                    $window.localStorage.setItem('token', token);
                else
                $window.localStorage.removeItem('token');
            }
            return authTokenFactory;
    })
    
    // the following method you request if token exists in local storage.
    // say it exists 
    //if you go to another url and it requires you to login in it will check config
    // config - the headers  in postman when you want to login you have to pass it in
    
    .factory('AuthInterceptor', function($q, $location,AuthToken){
            var interceptorFactory = {};
            interceptorFactory.request = function(config){
                var token = AuthToken.getToken();
                if(token) {
                    config.headers['x-access-token'] = token;
                  
                }
                return config;
        };
        
        // add in error checking ; if you try to access a homepage w/o token
        // and you are not logged in it will redirect you to the login page
        
        interceptorFactory.responseError = function(response) {
            if(response.status == 403)
                $location.path('/login');
            return $q.reject(response);
    ) 
    
            return interceptorFactory;
});  
